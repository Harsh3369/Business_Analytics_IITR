####################### Module 3 Assignment ##########################################


##Get Current Working Directory
getwd()

##Set working Directory to current folder
setwd('~/Module_3_Assignment/')

###Load and Install Required Packages
install.packages('readxl')
install.packages('modeest')
install.packages('moments')
install.packages('dplyr')
install.packages("ggplot2")
install.packages("plotly")

library(readxl)
library(modeest)
library(moments)
library(dplyr)
library(ggplot2)
library(plotly)

##*********************************************************************************************##

## Task 1:Import the data to check its class and structure and display the head and tail of the data

#Import data
input_df <- read_excel('Input_data.xlsx')
print('------------------------')
#Check the class of the data frame
class(input_df)
print('------------------------')
#Check the structure of the data frame
str(input_df)
print('------------------------')
#Print the head of dataframe
head(input_df)
print('------------------------')

#Print the tail of dataframe
tail(input_df)
print('------------------------')

##*********************************************************************************************##

## Task 2: Calculate variaous parameters (listed below)

#a.Difference in the means of the pre and post variables
diff_mean = mean(input_df$Pre, na.rm = T) - mean(input_df$Post,na.rm = T)
print(diff_mean)
print('------------------------')


#b.Values that divide the pre and post variable data into equal halves : MEDIAN
pre_median = median(input_df$Pre, na.rm = T)
print(pre_median)
print('------------------------')

post_median = median(input_df$Post, na.rm = T)
print(post_median)
print('------------------------')

#c.Mode for the pre variable
pre_mode <- mfv(input_df$Pre)
print(pre_mode)
print('------------------------')

#d.First and third quantile for the pre and post variables
pre_q1 <- quantile(input_df$Pre, 0.25)
print(pre_q1)
print('------------------------')
pre_q3 <- quantile(input_df$Pre, 0.75)
print(pre_q3)
print('------------------------')

post_q1 <- quantile(input_df$Post, 0.25)
print(post_q1)
print('------------------------')
post_q3 <- quantile(input_df$Post, 0.75)
print(post_q3)
print('------------------------')

#e.Range of the pre and post variables
pre_range <- range(input_df$Pre)
print(pre_range)
print('------------------------')
post_range <- range(input_df$Post)
print(post_range)
print('------------------------')

#f.Variance and standard deviation for the pre and post variables
pre_variance <- var(input_df$Pre)
print(pre_variance)
print('------------------------')
post_variance <- var(input_df$Post)
print(post_variance)
print('------------------------')

pre_sd <- sd(input_df$Pre)
print(pre_sd)
print('------------------------')
post_sd <- sd(input_df$Post)
print(post_sd)
print('------------------------')

#g.Coefficient of variation and mean absolute deviation for the pre and post variables
pre_cv <- sd(input_df$Pre) / mean(input_df$Pre) * 100
print(pre_cv)
print('------------------------')
post_cv <- sd(input_df$Post) / mean(input_df$Post) * 100
print(post_cv)
print('------------------------')

pre_mad <- mean(abs(input_df$Pre - mean(input_df$Pre)))
print(pre_mad)
print('------------------------')

post_mad <- mean(abs(input_df$Post - mean(input_df$Post)))
print(post_mad)
print('------------------------')

#h.Interquartile range of the pre and post variables
pre_iqr <- pre_q3 - pre_q1
print(pre_iqr)
print('------------------------')

post_iqr <- post_q3 - post_q1
print(post_iqr)
print('------------------------')


##*********************************************************************************************##

## Task 3:Measure the skewness for pre and post variables and apply the Agostino test to check the skewness

# Calculate the skewness for the Pre variable
skewness_pre <- skewness(input_df$Pre)
print(skewness_pre)
print('------------------------')

# Calculate the skewness for the Post variable
skewness_post <- skewness(input_df$Post)
print(skewness_post)
print('------------------------')

# Apply the Agostino test to the Pre variable
agostino_test_pre <- agostino.test(input_df$Pre)
print(agostino_test_pre)
print('------------------------')

# Apply the Agostino test to the Post variable
agostino_test_post <- agostino.test(input_df$Post)
print(agostino_test_post)
print('------------------------')

##*********************************************************************************************##

## Task 4:Identify the nature of distribution through kurtosis for both pre and post variables and confirm the result through the Anscombe test

# Calculate the kurtosis for the Pre variable
kurtosis_pre <- kurtosis(input_df$Pre)
print(kurtosis_pre)
print('------------------------')

# Calculate the kurtosis for the Post variable
kurtosis_post <- kurtosis(input_df$Post)
print(kurtosis_post)
print('------------------------')

# Apply the Anscombe test to the Pre variable
anscombe_test_pre <- anscombe.test(input_df$Pre)
print(anscombe_test_pre)
print('------------------------')

# Apply the Anscombe test to the Post variable
anscombe_test_post <- anscombe.test(input_df$Post)
print(anscombe_test_post)
print('------------------------')


##*********************************************************************************************##

## Task 5:Plot a graph to check the skewness and peakedness in the distribution of pre and post variables

# Plot the distribution of the pre variable
plot(density(input_df$Pre), main="Distribution of Pre Variable",
     xlab="Value", ylab="Density",
     sub=paste("Skewness:", skewness_pre, "Kurtosis:", kurtosis_pre))

print('-----------------------')

# Plot the distribution of the post variable
plot(density(input_df$Post), main="Distribution of Post Variable",
     xlab="Value", ylab="Density",
     sub=paste("Skewness:", skewness_post, "Kurtosis:", kurtosis_post))

print('-----------------------')

##*********************************************************************************************##

## Task 6:Compute the frequency and relative frequency for each brand of cold drink

# Calculate the frequency and relative frequency for each brand
df_grouped <- input_df %>%
  group_by(input_df$`Cold-Drink`) %>%
  summarise(
    frequency = n(),
    relative_frequency = n() / dim(input_df)[1]
  )

# Rename the column
df_grouped <- df_grouped %>%
  rename(cold_drink = `input_df$\`Cold-Drink\``)

print(df_grouped)

print('-----------------------')

##*********************************************************************************************##

## Task 7:Create a pie chart and bar chart to show the preferences of the cold drinks available and provide the necessary labels

# Create a pie chart
pie_chart <- df_grouped %>% 
  plot_ly(labels = ~cold_drink,values = ~frequency, type = "pie") %>%  
  layout(title = "Preferences of Cold Drinks",
         xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
         yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))  

pie_chart